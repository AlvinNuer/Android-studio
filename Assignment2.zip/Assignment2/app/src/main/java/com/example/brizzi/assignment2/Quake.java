package com.example.brizzi.assignment2;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


class MyChart extends View
{
    Paint paint;
    Canvas canvas;
    static int x = 0;

    static float valX[], valY[], valZ[];

    static int hd = 143, tl = 0;

    public MyChart (Context context)
    {
        super(context);

        paint = new Paint();
        paint.setColor (Color.BLACK);

        valX = new float[144];
        valY = new float[144];
        valZ = new float[144];

        for (int i = 0; i < 144; i ++)
        {
            valX[i] = 0;
            valY[i] = 0;
            valZ[i] = 0;
        }
    }

    @Override
    protected void onDraw (Canvas c)
    {
        int i;

        int ptr;

        super.onDraw (c);

        c.drawPaint (paint);
        paint.setAntiAlias (true);

        c.drawColor(Color.BLACK);

        paint.setStyle (Paint.Style.STROKE);


        paint.setStrokeWidth (6);

        canvas = c;

        ptr = tl;

        for (i = 0; i < 143; i++)
        {
            int ptr2 = (ptr + 1) % 144;

            paint.setColor (Color.GREEN);
            canvas.drawLine(i * 10, 300 + valX[ptr], i * 10 + 10, 300 + valX[ptr2], paint);

            paint.setColor (Color.YELLOW);
            canvas.drawLine(i * 10, 600 + valY[ptr], i * 10 + 10, 600 + valY[ptr2], paint);

            paint.setColor (Color.BLUE);
            canvas.drawLine(i * 10, 900 + valZ[ptr], i * 10 + 10, 900 + valZ[ptr2], paint);


            ptr = (ptr + 1) % 144;
        }
    }
}

public class Quake extends AppCompatActivity implements SensorEventListener {

    SensorManager sensorManager;
    MyChart d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quake);

        d = new MyChart (this);
        setContentView (d);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        // for the system's orientation sensor registered listeners
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        // to stop the listener and save battery
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {
        // TODO Auto-generated method stub
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        // TODO Auto-generated method stub
        String s = String.format ("X:%07.4f\nY:%07.4f\nZ:%07.4f\nG:%07.4f", event.values[0], event.values[1], event.values[2], Math.sqrt(event.values[0]*event.values[0]+event.values[1]*event.values[1]+event.values[2]*event.values[2]));
        Log.i("ACC", s);

        MyChart.valX[MyChart.hd] = (int)event.values[0]*10;
        MyChart.valY[MyChart.hd] = (int)event.values[1]*10;
        MyChart.valZ[MyChart.hd] = (int)event.values[2]*10;

        MyChart.hd = (MyChart.hd + 1) % 144;
        MyChart.tl = (MyChart.tl + 1) % 144;

        d.invalidate();
    }
}
