package com.example.brizzi.assignment2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.brizzi.assignment2.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

class AddressbookEntry
{
    String id;
    String longitude;
    String latitude;
    String date;


    public AddressbookEntry (String i, String la, String lo, String da)
    {
        id = i;
        latitude = la;
        longitude = lo;
        date = da;

    }
}

class AddressbookList
{
    static AddressbookEntry[] addressbookEntry;
    static int count = 0;
    static int newsInFocus = -1;

    public static void init (int n)
    {
        addressbookEntry = null; // OLD RECORDS IS NOW GARBAGE
        addressbookEntry = new AddressbookEntry[n];
        count = n;
    }
}

public class Database extends Activity {
    AddressbookEntry ab;
    int n = -1;
    String la;
    String lo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        //https://www.youtube.com/watch?v=BWofh32u0wk
        Intent intent=getIntent(); // get data from previous activity
        lo = intent.getStringExtra("longi");//store data in variable
        la = intent.getStringExtra("lati");//store data in variable

        EditText t1 = (EditText) findViewById(R.id.editText1);
        t1.setText(lo);// set variable in textView

        EditText t2 = (EditText) findViewById(R.id.editText2);
        t2.setText(la);// set variable in textView

        final Button b1 = (Button) findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
                                  public void onClick(View view) {
                                      if (n > 0) {
                                          n--;
                                          loadRecord();
                                      }
                                  }
                              }
        );

        final Button b2 = (Button) findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
                                  public void onClick(View view) {
                                      new Thread() {
                                          @Override
                                          public void run() {

                                              final String s = getContent("http://194.81.104.22/~16442196/loadAssignment.php?");

                                              runOnUiThread(new Thread(new Runnable() {
                                                  public void run() {
                                                      parseContent(s);
                                                      n = 0;
                                                      loadRecord();
                                                  }
                                              }));
                                          }
                                      }.start();
                                  }
                              }
        );

        final Button b3 = (Button) findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
                                  public void onClick(View view) {
                                      if (n < AddressbookList.count - 1) {
                                          n++;
                                          loadRecord();
                                      }
                                  }
                              }
        );

        final Button b4 = (Button) findViewById(R.id.button4);
        b4.setOnClickListener(new View.OnClickListener() {
                                  public void onClick(View view) {
                                      addRecord();
                                  }
                              }
        );


        final Button b6 = (Button) findViewById(R.id.button6);
        b6.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View view) {
                        deleteRecord ();
                    }
                }
        );
    }

    public String getContent(String theURL) {
        String s = "";

        try {
            URL url = new URL(theURL);
            URLConnection connection = url.openConnection();
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            int responseCode = httpConnection.getResponseCode();
            int l = httpConnection.getContentLength();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream in = httpConnection.getInputStream();
                InputStreamReader inn = new InputStreamReader(in);
                BufferedReader bin = new BufferedReader(inn);

                do {
                    s = s + bin.readLine() + "\n";
                }
                while (s.length() < l);

                in.close();
            } else {
            }
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        } finally {
        }

        return s;
    }

    public static void parseContent(String s) {
        //Log.i("DB", "HELP"+s);
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            ;
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document dom = db.parse(new ByteArrayInputStream(s.getBytes()));
            Element docEle = dom.getDocumentElement();

            NodeList nl = docEle.getElementsByTagName("record");

            if (AddressbookList.count == -1) {
                AddressbookList.init(nl.getLength());
            } else // Unlikely!
            {
                AddressbookList.count = -1;
                AddressbookList.addressbookEntry = null;
                AddressbookList.init(nl.getLength());
            }

            for (int i = 0; i < nl.getLength(); i++) {
                Element entry = (Element) nl.item(i);

                AddressbookList.addressbookEntry[i] = new AddressbookEntry("", "", "", "");

                Element id = (Element) entry.getElementsByTagName("id").item(0);
                Element longitude = (Element) entry.getElementsByTagName("longitude").item(0);
                Element latitude = (Element) entry.getElementsByTagName("latitude").item(0);
                Element date = (Element) entry.getElementsByTagName("date").item(0);

                AddressbookList.addressbookEntry[i].id = id.getFirstChild().getNodeValue();
                AddressbookList.addressbookEntry[i].longitude = longitude.getFirstChild().getNodeValue();
                AddressbookList.addressbookEntry[i].latitude = latitude.getFirstChild().getNodeValue();
                AddressbookList.addressbookEntry[i].date = date.getFirstChild().getNodeValue();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } finally {
        }
    }

    public void loadRecord() {
        TextView t1 = (TextView) findViewById(R.id.textView01);
        t1.setText(AddressbookList.addressbookEntry[n].id);

        EditText e1 = (EditText) findViewById(R.id.editText1);
        e1.setText(AddressbookList.addressbookEntry[n].longitude);

        EditText e2 = (EditText) findViewById(R.id.editText2);
        e2.setText(AddressbookList.addressbookEntry[n].latitude);

        TextView t3 = (TextView) findViewById(R.id.textView4);
        t3.setText(AddressbookList.addressbookEntry[n].date);


    }

    public void addRecord() {
        EditText e1 = (EditText) findViewById(R.id.editText1);
        final String o = e1.getText().toString();

        EditText e2 = (EditText) findViewById(R.id.editText2);
        final String a = e2.getText().toString();

        /*EditText e3 = (EditText) findViewById(R.id.editText3);
        final String d = e3.getText().toString();*/

        new Thread() {
            @Override
            public void run() {
                final String s = getContent ("http://194.81.104.22/~16442196/addAssignment.php?longitude=" + o + "&latitude=" + a);                      runOnUiThread(new Thread(new Runnable() {
                    public void run() {
                        parseContent(s);
                        n++;
                        loadRecord();
                    }
                }));
            }
        }.start();
    }

    public void deleteRecord ()
    {
        TextView t1 = (TextView)findViewById(R.id.textView01);
        final String i = t1.getText ().toString ();

        new Thread ()
        {
            @Override
            public void run ()
            {
                final String s = getContent ("http://194.81.104.22/~16442196/deleteAssignment.php?id=" + i);
                //final TextView t = (TextView)findViewById(R.id.textView1);

                runOnUiThread (new Thread(new Runnable()
                {
                    public void run()
                    {
                        parseContent (s);
                        if (n > 0) n --;
                        loadRecord ();
                    }
                }));
            }
        }.start ();
    }
}