package com.example.brizzi.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    Button button_cam;
    Button button_map;
    Button button_sens;
    Button button_dat;
    Button button_comp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button_cam=(Button) findViewById(R.id.button_camera );
        button_cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCamera();
            }
        });

        button_map=(Button) findViewById(R.id.button_map);
        button_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMap();
            }
        });

        button_sens=(Button) findViewById(R.id.button_sensor);
        button_sens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSensor();
            }
        });

        button_dat=(Button) findViewById(R.id.button_data);
        button_dat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startData();
            }
        });


        button_comp=(Button) findViewById(R.id.button_compass);
        button_comp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCompass();
            }
        });
    }

    public void startCamera(){

        Intent intent_Camera= new Intent(this, Camera.class);
        startActivity(intent_Camera);

    }

    public void startMap(){
        Intent intent_Map = new Intent(this, Map.class);
        startActivity(intent_Map);
    }

    public void startSensor(){
        Intent intent_Sensor = new Intent(this, Quake.class);
        startActivity(intent_Sensor);
    }
    public void startData(){
        Intent intent_Data = new Intent(this, Database.class);
        startActivity(intent_Data);
    }
    public void startCompass(){
        Intent intent_Compass = new Intent(this, Compass.class);
        startActivity(intent_Compass);
    }


}
